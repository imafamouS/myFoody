package com.fdsa.infamous.myfoody.common.myenum;

/**
 * Created by FDSA on 4/9/2017.
 */

//Enum code để lấy ảnh của các đối tượng MoreItem
public enum MoreItemCode {
    NEARBY,
    BOOK,
    ECARD,
    REVIEW,
    TOPMEMBER,
    COUPON,
    DELIVERY,
    GAME_FUN,
    BLOGS,
    VIDEO
}