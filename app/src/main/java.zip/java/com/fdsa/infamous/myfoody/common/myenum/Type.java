package com.fdsa.infamous.myfoody.common.myenum;

/**
 * Created by FDSA on 3/22/2017.
 */
//Enum các loại của các Tab Menu
public enum Type {
    LATEST,
    CATEGORY,
    DISTRICT,
    STREET,
    IMAGE_INFILE,
    IMAGESELECTED_INFILE,
    IMAGESELECTED_INADDPLACE
}
