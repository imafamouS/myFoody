package com.fdsa.infamous.myfoody.common.myinterface;

/**
 * Created by FDSA on 4/9/2017.
 */

/***
 * Interface chứa sự kiện khi người dùng click Layout trên MoreItemView
 */
public interface IMoreItemClick {
    void moreItemClick(int pos);
}