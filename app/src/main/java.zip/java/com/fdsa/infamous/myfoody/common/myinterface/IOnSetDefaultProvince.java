package com.fdsa.infamous.myfoody.common.myinterface;

/**
 * Created by FDSA on 4/10/2017.
 */

/***
 * Interface chứa hàm xử lí khi nhấn nút mặc định (trong activity chọn tỉnh thành)
 */
public interface IOnSetDefaultProvince {
    void onSetDefaultProvince();
}
