package com.fdsa.infamous.myfoody.common.myinterface;

/**
 * Created by FDSA on 4/10/2017.
 */

/**
 * Interface chứa hàm sự lí sự kiện khi nhấn vào các tab trên top menu (Ở đâu, ăn gì)
 **/
public interface IOnTopMenuBarChange {
    void OnTopMenuBarChange(int index);
}