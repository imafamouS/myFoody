package com.fdsa.infamous.myfoody.common.myinterface;

/**
 * Created by FDSA on 4/23/2017.
 */

public interface IRestaurantItemClick {
    void RestaurantItemCLick(int position);
}
