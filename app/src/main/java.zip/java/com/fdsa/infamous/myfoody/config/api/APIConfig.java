package com.fdsa.infamous.myfoody.config.api;

/**
 * Created by FDSA on 4/22/2017.
 */

public class APIConfig {

    public static final String BASE_URL = "http://10.0.3.2:8080/MyFoodyWebService/rest/"; //Change
    public static final String BASE_URL_IMAGE = BASE_URL+"image?id=";

    public static final boolean POST = true;
    public static final boolean GET = false;
}
